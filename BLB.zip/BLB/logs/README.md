# Instruction

Place your log data here. Following the naming and path of logs as `<ProjHome>/logs/<LOGNAME>/<LOGNAME.log>`

Please download log data from our Zenodo dataset [here](https://zenodo.org/records/13756047)

Next, decompress each `.zip` here (`<ProjHome>/logs/`)